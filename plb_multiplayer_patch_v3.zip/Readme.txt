Modpage:
https://www.nexusmods.com/baldursgate3/mods/327

Multiplayer Patch Installation:
1. Unzip this mod.
2. Drag and drop either your bg3.exe or bg3_dx11.exe file onto the PartyLimitBegonePatcher.bat file. It will create a backup for you.
3. That's it! Enjoy the game. Note: bg3.exe is used if vulkan is selected in the larian launcher and bg_dx11.exe if directx is selected instead.

About Linux and Mac support:
Both the standalone and SE versions should work on linux and mac. As for the MP patch, it only works with the windows client so mac users have to use that one, the native mac client is not supported. Only the host needs to have the MP patch installed though! Asking a friend to share their patched exe file is the easiest solution. Otherwise you must edit the PartyLimitBegonePatcher.bat file with any text editor and change this line: Set "GetFileName=%~n1.exe" to something like Set "GetFileName=bg3.exe" then place your bg3.exe file next to it - in to the same folder and run the PartyLimitBegonePatcher.bat file with wine﻿.

Uninstall MP Patch:
Delete the patched exe file and restore your backup. The patcher creates a bg3.exe.backup (or bg3_dx11.exe.backup) file in your game folder, simply rename it back to bg3.exe. (or bg3_dx11.exe)
