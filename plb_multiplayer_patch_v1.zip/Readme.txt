Multiplayer Installation:
1. Unzip this mod.
2. Drag and drop either your bg3.exe or bg3_dx11.exe file onto the PartyLimitBegonePatcher.bat file. It will create a backup for you.
3. That's it! Enjoy the game.

Mod by Sildur:
https://www.nexusmods.com/baldursgate3/mods/327
