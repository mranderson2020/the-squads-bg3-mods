Installation (Standalone version):
1. Download and unzip this mod.
2. Move the whole Mods folder in to your Baldurs Gate 3 Data folder. That's the game folder, not appdata.
3. That's it, enjoy the game! Note: Dismiss one party member if you already have 4, this will reset the party limit and set it to 16.

Mod by Sildur:
https://www.nexusmods.com/baldursgate3/mods/327
